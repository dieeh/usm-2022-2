Integrantes del grupo:

Diego Paz, rol 202004502-K
Ronald Bruno, rol 202030563-3