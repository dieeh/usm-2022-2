Nombres:
Diego Paz Letelier, 202004502-k
Carlos Müller Navarro, 202004590-9

Para que funcione hay que cambiar los strings server y database en las líneas 31 y 32 
por el servidor y base de datos local correspondiente, luego ejecutar el archivo server.py para 
que se genere la conexión.